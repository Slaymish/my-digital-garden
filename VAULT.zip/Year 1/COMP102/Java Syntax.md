Related: #java #terms 
Hamish Burke || 31-01-2023
***

### Import Statments
```java
import ecs100.*; 
```

  
### Example Class
```java
public class <classname> {  
	method here  
}
```


## Comments

#### Documentation Comments
```java
/** Only used at top of class, and the describe method. Show up in debug mode  */
```


#### End of line comments
````java
// Any place at end of line 

/* 
These are 
multi-line comments
*/
````



## Method Calls

```java
object.methodname(parameters);

//eg
Math.pow(10,2);
```


### [[#ECS Methods]]

-   quit()
-   addButton()
-   pirntln()
-   drawRect()
-   [[clearGraphics()]]
-   askDouble()
-   askString()
-  [[setupGUI()]]


