Hamish Burke || 07-02-2023
***

#### Key interests
- #Socialism
- #programming 
- #3dDesign
- #RubixCubing
- #Gym
- #math

***

### How can I expand upon these things?
- Socialist
	- Become politically active
		- Organize community events that promote social justice and equality
		- Socialist meetings
		- Get in government
		- Volunteer for or donate to organizations that align with your socialist values
		- Collaborate with other socialist activists to create joint projects and campaigns
	- Make content
		- Debates
		- Start a podcast or write articles to share socialist ideas and views
		- Explaination vids
- Programmer
	- Offer tech support or consulting services for small businesses and individuals
	- Make a software/app
	- Hack into companies
		- For money
		- Or activism
	- Web development
		- Create own style
		- Create probono and paid websites for people
	- Create and sell online courses or tutorials on programming
	-  Participate in coding hackathons or contests
	-  Develop open-source projects and contribute to existing ones
- 3d Designer
	- Sell models
	- Blender youtube/instagram/tiktok
	- Offer design and animation services for films, video games, and advertising
	- Create and sell virtual reality or augmented reality experiences
	- Create and sell 3D printed products
	- Collaborate with artists, musicians, and creatives to create immersive multimedia installations
- Rubix cuber
	- Compete in speedcubing
	- Teach others how to solve the Rubik's Cube through workshops, tutorials, or classes
	- Create and sell customized Rubik's Cubes or accessories
	- Create and share solving algorithms or strategies on social media or forums
- Gym goer
	- Body builder compeditions
	- Gym influencer
	- Model
	- Offer personal training services to others
	- Collaborate with gyms, fitness brands, or sports nutrition companies to promote their products and services
- Math
	- Create engineering models for people
	- Offer private tutoring or teaching services for students of all ages
	- Create educational videos or articles that make math accessible and engaging for everyone
	- Participate in math contests or challenges
	- Develop and sell educational games, apps, or websites that help people learn and practice math skills.



