## This is a code example

```java
public static void main(){
	println("test");
}
```


