Related: #3dDesign #Socialism 
Hamish Burke || 07-02-2023
***

I want to make a piece of art depicting a (pride?) parade. There will be a army of robots 'keeping the peace'. The robots will all have guns.

Things I want to add:
- A robot standing on a protesters neck
- Some noticable brand logos on the killer robots