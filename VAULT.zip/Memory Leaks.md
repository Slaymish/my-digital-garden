Related: #java #programming
Hamish Burke || 01-02-2023
***
Happens when a software doesn't free their memory after using it.

- Uses up memory on computer
- Things run slower
- Systems can't boot

Happens in
- C++
- C
- etc

***
## [[Garbage Collection]] solves this issue
