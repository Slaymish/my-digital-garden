Related: #algebra #practise 
Hamish Burke || 31-01-2023
***

#### Use the distributive property to simplify each expression

1. $2(4+9w)$
	$=8+18w$

2. $-4(-4d-5)$
	$=16d+20$

3. $2(3v-8)$
	$=6v-16$

4. $4(-6z+4)$
	$=-24z+16$

