| Column 1 | Column 2 | Column 3 |
| -------- | -------- | -------- |
| Data 1A  | Data 2A  | Data 3A  |
| Data 1B  | Data 2B  | Data 3B  |
| Data 1C | Data 2C | Data 3C |