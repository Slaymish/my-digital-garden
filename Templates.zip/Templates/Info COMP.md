---
dg-home: false
dg-publish: true
---
Related: #programming #java 
Contents: [[COMP MOC]]
[Lecture Schedule](https://ecs.wgtn.ac.nz/Courses/COMP261_2023T1/LectureSchedule)
[[UNI MOC]]
Hamish Burke || {{date}}
***
