---
dg-home: false
dg-publish: true
---
Related: #
Contents: [[SWEN_MOC]]
[Lecture Schedule](https://ecs.wgtn.ac.nz/Courses/SWEN221_2023T1/LectureSchedule)
[[UNI MOC]]
Hamish Burke || {{date}}
***
